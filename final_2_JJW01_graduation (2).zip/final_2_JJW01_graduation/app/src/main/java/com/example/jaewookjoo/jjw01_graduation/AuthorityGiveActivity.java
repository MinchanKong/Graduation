package com.example.jaewookjoo.jjw01_graduation;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.example.jaewookjoo.jjw01_graduation.Request.AuthorityLogInsertRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryLogSelectNoRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryLogUpdateOpenerRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryUpdateRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.StudentListCheckRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.SubjectCheckRequest;
import com.example.jaewookjoo.jjw01_graduation.SecureCoding.Encryption;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AuthorityGiveActivity extends LoginActivity {
    EditText authorityGiveUniqueNo;
    Button checkAuthorityGiveButton;
    Button checkAuthorityGiveButton2;
    Button checkAuthorityGiveButton3;

    String receiveAuthorityUniqueNo;
    String subject_uniqueNo;
    String dateTime;

    android.support.v7.app.AlertDialog.Builder mBuilder;
    Response.Listener<String> responseListener1;
    Response.Listener<String> responseListener2;
    Response.Listener<String> responseListener3;
    Response.Listener<String> responseListener33;
    Response.Listener<String> responseListener4;
    Response.Listener<String> responseListener66;
    int laboratory_No;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authoritygive);

        authorityGiveUniqueNo = (EditText)findViewById(R.id.authorityGiveUniqueNo);
        checkAuthorityGiveButton = (Button)findViewById(R.id.checkAuthorityGiveButton);
        checkAuthorityGiveButton2 = (Button)findViewById(R.id.checkAuthorityGiveButton2);
        checkAuthorityGiveButton3 = (Button)findViewById(R.id.checkAuthorityGiveButton3);

        Toast.makeText(AuthorityGiveActivity.this,"권한 넘겨받는 상대방 학번을 입력해주세요.",Toast.LENGTH_SHORT).show();

        checkAuthorityGiveButton2.setEnabled(false);
        checkAuthorityGiveButton3.setEnabled(false);

        checkAuthorityGiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date now = new Date();
                dateTime = new SimpleDateFormat("yyyy.MM.dd..HHmmss").format(now);
                receiveAuthorityUniqueNo = authorityGiveUniqueNo.getText().toString();

                startResponse1();
            }

        });

        checkAuthorityGiveButton2.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                    startResponse2();
                    startResponse6();
            }
        });

        checkAuthorityGiveButton3.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                startFinal();

            }
        });


        ///////////// 1. student_list확인  php 작업
        responseListener1 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success){
                        subject_uniqueNo = jsonResponse.getString("subject_uniqueNo");
                        Toast.makeText(AuthorityGiveActivity.this,"존재하는 학번입니다." ,Toast.LENGTH_SHORT).show();
                        checkAuthorityGiveButton.setText("");
                        checkAuthorityGiveButton2.setText("강의실 확인");
                        checkAuthorityGiveButton.setEnabled(false);
                        checkAuthorityGiveButton2.setEnabled(true);
                        authorityGiveUniqueNo.setEnabled(false);
                    }
                    else{
                        Toast.makeText(AuthorityGiveActivity.this,"존재하지 않는 학번입니다." ,Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        //////////////////////////////////////////////2. subject 확인
        responseListener2 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success){
                        Toast.makeText(AuthorityGiveActivity.this, "E513 실습실을 사용하는 과목입니다." ,Toast.LENGTH_LONG).show();
                        checkAuthorityGiveButton.setText("");
                        checkAuthorityGiveButton2.setText("");
                        checkAuthorityGiveButton3.setText("최종 확인");

                        checkAuthorityGiveButton2.setEnabled(false);
                        checkAuthorityGiveButton3.setEnabled(true);
                    }
                    else{
                        Toast.makeText(AuthorityGiveActivity.this, "E513 실습실을 사용하는 과목이 아닙니다." ,Toast.LENGTH_LONG).show();
                        checkAuthorityGiveButton2.setEnabled(false);

                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        ////////////////////////// 3. laboratory 테이블 update 권한 이전.//////////////////////////////////////
        // 조건 : roomName, 처음 uniqueNo ( holder ) -> 있다면 holder를 receiveAuthorityUniqueNo로 update
        responseListener3 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success){
           //             Toast.makeText(AuthorityGiveActivity.this,"권한이 수정되었습니다." ,Toast.LENGTH_LONG).show();
                    }
                    else{
          //              Toast.makeText(AuthorityGiveActivity.this,"권한 수정하는데 실패 하였습니다." ,Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        responseListener33 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success){
           //             Toast.makeText(AuthorityGiveActivity.this,"laboratory_log opener 성공" ,Toast.LENGTH_LONG).show();
                    }
                    else{
            //            Toast.makeText(AuthorityGiveActivity.this,"laboratory_log opener 실패" ,Toast.LENGTH_LONG).show();

                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        //////////////////////////// 4. 권한 이전 로그 Insert /////////////////////////////////////////
        responseListener4 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success){
                        Toast.makeText(AuthorityGiveActivity.this, "권한 이동 로그처리가 되었습니다. (" + receiveAuthorityUniqueNo +")" ,Toast.LENGTH_LONG).show();
                        checkAuthorityGiveButton3.setEnabled(false);
                    }
                    else{
                        Toast.makeText(AuthorityGiveActivity.this,"권한 이동 로그처리 실패 되었습니다." ,Toast.LENGTH_LONG).show();
                        checkAuthorityGiveButton3.setEnabled(false);
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };



        responseListener66 = new Response.Listener<String>(){               // laboratory_log No 가져오기

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");
                    if(success) {    // success 만으로 가능하다는 것이므로
                        laboratory_No= jsonResponse.getInt("no");
          //              Toast.makeText(AuthorityGiveActivity.this, "로그번호 : " + laboratory_No, Toast.LENGTH_SHORT).show();
                    }
                    else{
           //             Toast.makeText(AuthorityGiveActivity.this, "아ㅓㄴ된다 : " , Toast.LENGTH_SHORT).show();
                    }
                    // }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

    }



    public void startFinal(){
        mBuilder = new android.support.v7.app.AlertDialog.Builder(AuthorityGiveActivity.this);
  //      if (finalState) {
            mBuilder.setMessage("넘기려는 학번 : " + receiveAuthorityUniqueNo + "가 맞습니까?");
            mBuilder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                        startResponse3();
                        startResponse4();
                        startResponse5();
                        Toast.makeText(AuthorityGiveActivity.this,"권한이전이 되었습니다.",Toast.LENGTH_SHORT).show();
                }
            });
            mBuilder.setNegativeButton("취소", null);
            mBuilder.show();

    }
    public void startResponse1(){
        StudentListCheckRequest studentListCheckRequest = new StudentListCheckRequest(receiveAuthorityUniqueNo, responseListener1);
        RequestQueue queue = Volley.newRequestQueue(AuthorityGiveActivity.this);
        queue.add(studentListCheckRequest);
    }

    public void startResponse2(){
        SubjectCheckRequest subjectCheckRequest = new SubjectCheckRequest(subject_uniqueNo,"E513",responseListener2);
        RequestQueue queue2 = Volley.newRequestQueue(AuthorityGiveActivity.this);
        queue2.add(subjectCheckRequest);
    }

    public void startResponse3() {
        LaboratoryUpdateRequest laboratoryUpdateRequest = new LaboratoryUpdateRequest(receiveAuthorityUniqueNo,"E513",uniqueNo,responseListener3);
        RequestQueue queue3 = Volley.newRequestQueue(AuthorityGiveActivity.this);
        queue3.add(laboratoryUpdateRequest);
    }


    public void startResponse4() {
        AuthorityLogInsertRequest authorityLogInsertRequest = new AuthorityLogInsertRequest(Integer.parseInt(manager_responsibilityNo),"E513", uniqueNo, receiveAuthorityUniqueNo, dateTime, responseListener4);
        RequestQueue queue4 = Volley.newRequestQueue(AuthorityGiveActivity.this);
        queue4.add(authorityLogInsertRequest);
    }

    public void startResponse5() {              // 실습실 로그에서 uniqueNo도 바꿔줘야함
        LaboratoryLogUpdateOpenerRequest laboratoryLogUpdateOpenerRequest = new LaboratoryLogUpdateOpenerRequest(receiveAuthorityUniqueNo, laboratory_No , responseListener33);
        RequestQueue queue5 = Volley.newRequestQueue(AuthorityGiveActivity.this);
        queue5.add(laboratoryLogUpdateOpenerRequest);
    }

    public void startResponse6(){
        LaboratoryLogSelectNoRequest laboratoryLogSelectNoRequest = new LaboratoryLogSelectNoRequest("E513", uniqueNo , responseListener66); //시간
        RequestQueue queue6 = Volley.newRequestQueue(AuthorityGiveActivity.this);
        queue6.add(laboratoryLogSelectNoRequest);                               // where 문을 E513, 2012151039, 시간으로 설정해야 중복없이 가능.수정할것   openTime 이랑 closeTime 으로 변수를 지정해놓기.
    }




}
