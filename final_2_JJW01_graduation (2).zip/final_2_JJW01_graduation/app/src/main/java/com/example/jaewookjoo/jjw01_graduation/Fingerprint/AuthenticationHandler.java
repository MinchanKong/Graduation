package com.example.jaewookjoo.jjw01_graduation.Fingerprint;

import android.app.Activity;
import android.content.Intent;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.jaewookjoo.jjw01_graduation.FingerprintActivity;
import com.example.jaewookjoo.jjw01_graduation.MainActivity;
import com.example.jaewookjoo.jjw01_graduation.R;




public class AuthenticationHandler extends FingerprintManager.AuthenticationCallback{

    private FingerprintActivity fingerprintActivity;

    public AuthenticationHandler(FingerprintActivity fingerprintActivity){
        this.fingerprintActivity = fingerprintActivity;
    }

    @Override
    public void onAuthenticationError(int errorCode, CharSequence errString) {
        super.onAuthenticationError(errorCode, errString);
        this.update("지문인증 에러", false);
    }

    @Override
    public void onAuthenticationHelp(int helpCode, CharSequence helpString) {
        super.onAuthenticationHelp(helpCode, helpString);
//        this.update("Error: " + helpString, false);
        this.update(""+ helpString, false);    }

    @Override
    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
        super.onAuthenticationSucceeded(result);
        this.update("지문인증 성공", true);
    }

    @Override
    public void onAuthenticationFailed() {
        super.onAuthenticationFailed();
        this.update("지문인증 실패", false);
    }

    private void update(String s,boolean b){
        TextView textFP = (TextView) ((Activity)fingerprintActivity).findViewById(R.id.textFP);
        TextView textFP2 = (TextView) ((Activity)fingerprintActivity).findViewById(R.id.textFP2);
        ImageView imageView = (ImageView)((Activity)fingerprintActivity).findViewById(R.id.fingerprintimage);

        textFP.setText(s);

        if(b == true){
            // 색 변경
            imageView.setImageResource(R.mipmap.after_ic_launcher);
            textFP2.setText("지문인식 되었습니다.");

            Intent intent = new Intent(fingerprintActivity, MainActivity.class);
            fingerprintActivity.startActivity(intent);
            ((AppCompatActivity)fingerprintActivity).finish ( ) ;
        }
        else{
            // 색변경
        }
    }
}
