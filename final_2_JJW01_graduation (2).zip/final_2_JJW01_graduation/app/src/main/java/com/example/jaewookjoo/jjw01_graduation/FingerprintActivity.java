package com.example.jaewookjoo.jjw01_graduation;

import android.Manifest;
import android.app.KeyguardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.fingerprint.FingerprintManager;
import android.os.CancellationSignal;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jaewookjoo.jjw01_graduation.Fingerprint.AuthenticationHandler;
import com.example.jaewookjoo.jjw01_graduation.SecureCoding.Encryption;

import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class FingerprintActivity extends AppCompatActivity {
    private String KEY_NAME = "somekeyname";

    View mView;
    EditText secondEditText;
    private String secondPassword;
    private String id;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.dialog_fingerprint);
        setContentView(R.layout.activity_secondloginpage);

        KeyguardManager keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        FingerprintManager fingerprintManager = (FingerprintManager) getSystemService(FINGERPRINT_SERVICE);

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        password = intent.getStringExtra("password");
        secondPassword = intent.getStringExtra("secondPassword");
        ///////////////////////////////////////////////////////////////////////////


        if (!fingerprintManager.isHardwareDetected()) {
            Log.e("Hardware", "Finger print hardware not detected");
            return;
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.USE_FINGERPRINT)
                != PackageManager.PERMISSION_GRANTED) {
            Log.e("Permission", "Fingerprint permission rejected");
            return;
        }

        if (!keyguardManager.isKeyguardSecure()) {
            Log.e("Keyguard", "keyguard not enabled");
            return;
        }

        KeyStore keyStore;

        try {
            keyStore = KeyStore.getInstance("AndroidKeyStore");
        } catch (Exception e) {
            Log.e("KeyStore", e.getMessage());
            return;
        }

        KeyGenerator keyGenerator;

        try {
            keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        } catch (Exception e) {
            Log.e("KeyGenerator", e.getMessage());
            return;
        }

        try {
            keyStore.load(null);
            keyGenerator.init(
                    new KeyGenParameterSpec.Builder(KEY_NAME,
                            KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                            .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
                            .setUserAuthenticationRequired(true)
                            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_PKCS7)
                            .build());

            keyGenerator.generateKey();
        } catch (Exception e) {
            Log.e("Generating keys", e.getMessage());
            return;
        }

        Cipher cipher;

        try {
            cipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES
                    + "/" + KeyProperties.BLOCK_MODE_CBC
                    + "/" + KeyProperties.ENCRYPTION_PADDING_PKCS7);
        } catch (Exception e) {
            Log.e("Cipher", e.getMessage());
            return;
        }

        try {
            keyStore.load(null);
            SecretKey key = (SecretKey) keyStore.getKey(KEY_NAME, null);
            cipher.init(Cipher.ENCRYPT_MODE, key);

        } catch (Exception e) {
            Log.e("Secret key", e.getMessage());
        }


        FingerprintManager.CryptoObject cryptoObject = new FingerprintManager.CryptoObject(cipher);

        CancellationSignal cancellationSignal = new CancellationSignal();
        fingerprintManager.authenticate(cryptoObject, cancellationSignal, 0, new AuthenticationHandler(this), null);


        Button secondPwdButton = (Button) findViewById(R.id.secondPwdButton);

        secondPwdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(FingerprintActivity.this);
                mView = getLayoutInflater().inflate(R.layout.dialog_secondpassword, null);

                mBuilder.setView(mView);
                mBuilder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        secondEditText = (EditText) mView.findViewById(R.id.secondEditText);

                        Encryption en = new Encryption();
                        en.encryption(secondEditText.getText().toString());
                        String enSecondPassword = en.getPassword();

                        if (secondPassword.equals(enSecondPassword)) {
                            Intent intent = new Intent(FingerprintActivity.this, MainActivity.class);
                            intent.putExtra("id", id);
                            intent.putExtra("password", password);
                            intent.putExtra("secondPassword", secondPassword);
                            FingerprintActivity.this.startActivity(intent);

                        } else {
                            Toast.makeText(FingerprintActivity.this, "2차 비밀번호가 틀립니다.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                mBuilder.setNegativeButton("취소", null);
                mBuilder.show();
            }
        });
    }
}
