package com.example.jaewookjoo.jjw01_graduation;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.example.jaewookjoo.jjw01_graduation.Request.LoginRequest;
import com.example.jaewookjoo.jjw01_graduation.SecureCoding.Encryption;

import org.json.JSONObject;

import static java.lang.Thread.sleep;

public class LoginActivity extends AppCompatActivity {
    public static String uniqueNo;
    public static String name;
    public static String major;
    public static String manager_responsibilityNo;
    public static String subject_uniqueNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);

        final EditText loginId = (EditText) findViewById(R.id.loginId);
        final EditText loginPassword = (EditText) findViewById(R.id.loginPassword);
        final Button loginButton = (Button) findViewById(R.id.loginButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String id = loginId.getText().toString();
                String tempPassword = loginPassword.getText().toString();

                Encryption en = new Encryption();
                en.encryption(tempPassword);

                final String password = en.getPassword();

                Response.Listener<String> responseListener = new Response.Listener<String>(){

                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);


                            boolean success = jsonResponse.getBoolean("success");
                            if(success){
                                String id = jsonResponse.getString("id");
                                String password = jsonResponse.getString("password");
                                String secondPassword = jsonResponse.getString("secondPassword");

                                major = jsonResponse.getString("major");
                                name = jsonResponse.getString("name");
                                uniqueNo = jsonResponse.getString("uniqueNo");

                                Intent intent = new Intent(LoginActivity.this, FingerprintActivity.class);

                                intent.putExtra("id", id);
                                intent.putExtra("password", password);
                                intent.putExtra("secondPassword",secondPassword);

                                LoginActivity.this.startActivity(intent);
                            }
                            else{
                                AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
                                builder.setMessage("로그인에 실패하였습니다.")
                                        .setNegativeButton("다시 시도",null)
                                        .create()
                                        .show();
                            }

                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                };

                LoginRequest loginRequest = new LoginRequest(id,password,responseListener);
                RequestQueue queue = Volley.newRequestQueue(LoginActivity.this);
                queue.add(loginRequest);
            }
        });
    }//onCreate

}