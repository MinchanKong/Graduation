package com.example.jaewookjoo.jjw01_graduation;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryCheckRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.StudentListCheckRequest;

import org.json.JSONObject;

public class MainActivity extends LoginActivity {

    boolean success;
    String holder;
    Response.Listener<String> responseListener;
    Response.Listener<String> responseListener2;
    RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Toast.makeText(MainActivity.this,uniqueNo,Toast.LENGTH_SHORT).show();

        ///////////////////////////////
        /*
        1. 사용자 정보 출력
        2. nfc를 통해 실습실에 들어가있는경우 ( Laboratory테이블의 holder가 자기 자신 ) 자신의 소유권 출력
        3. 일단 E513 roomName을 고정시켜놓은 상태로 진행 ( 테스트 )

                                    */
        /////////////////////////////

        final Button nfcLaboratoryEnterButton = (Button) findViewById(R.id.nfcLaboratoryEnterButton);
        final Button authorityGive = (Button) findViewById(R.id.authorityGive);
        final Button troubleReport = (Button) findViewById(R.id.troubleReport);
        final Button nfcLaboratoryCloseButton = (Button) findViewById(R.id.nfcLaboratoryCloseButton);

        nfcLaboratoryEnterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 알림푸쉬 테스트


                Intent intent = new Intent(MainActivity.this,NfcLaboratoryEnterActivity.class);
                startActivity(intent);
            }
        });

        nfcLaboratoryCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, NfcLaboratoryCloseActivity.class);
                startActivity(intent);
            }
        });

        //////////////////////

        responseListener = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    success = jsonResponse.getBoolean("success");
                    if(success){
                        String roomName = "E513";
                        manager_responsibilityNo = jsonResponse.getString("manager_responsibilityNo");
                        String secondPassword = jsonResponse.getString("secondPassword");
                        holder = jsonResponse.getString("holder");
                        Boolean status = jsonResponse.getBoolean("status");
                        String logNo = jsonResponse.getString("logNo");
                        //              Toast.makeText()
                        //                       // authorityGive.setEnabled(true);
                        Toast.makeText(MainActivity.this,holder,Toast.LENGTH_SHORT).show();

                    }
                    else{
                    }

                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };


        responseListener2 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success){
                        subject_uniqueNo = jsonResponse.getString("subject_uniqueNo");
                    }

                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        StudentListCheckRequest studentListCheckRequest = new StudentListCheckRequest(uniqueNo, responseListener2);
        queue = Volley.newRequestQueue(MainActivity.this);
        queue.add(studentListCheckRequest);


        LaboratoryCheckRequest laboratoryCheckRequest = new LaboratoryCheckRequest("E513",uniqueNo,responseListener);
        queue = Volley.newRequestQueue(MainActivity.this);
        queue.add(laboratoryCheckRequest);

        /////////////////
        authorityGive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if(success){
                    Intent intent = new Intent(MainActivity.this,AuthorityGiveActivity.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(MainActivity.this,"불가능합니다.",Toast.LENGTH_SHORT).show();
                }

            }
        });

        troubleReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,TroubleReportActivity.class);
                startActivity(intent);
            }
        });




    }


    @Override
    protected void onResume() {
        super.onResume();

        responseListener = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    success = jsonResponse.getBoolean("success");
                    if(success){
                        String roomName = "E513";
                        manager_responsibilityNo = jsonResponse.getString("manager_responsibilityNo");
                        String secondPassword = jsonResponse.getString("secondPassword");
                        holder = jsonResponse.getString("holder");
                        Boolean status = jsonResponse.getBoolean("status");
                        String logNo = jsonResponse.getString("logNo");
                        //              Toast.makeText()
                        //                       // authorityGive.setEnabled(true);
                        Toast.makeText(MainActivity.this,holder,Toast.LENGTH_SHORT).show();

                    }
                    else{
                    }

                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };


        LaboratoryCheckRequest laboratoryCheckRequest = new LaboratoryCheckRequest("E513",uniqueNo,responseListener);
        RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
        queue.add(laboratoryCheckRequest);
    }
}
