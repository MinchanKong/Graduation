package com.example.jaewookjoo.jjw01_graduation;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcAdapter.CreateNdefMessageCallback;
import android.nfc.NfcAdapter.OnNdefPushCompleteCallback;
import android.nfc.NfcEvent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryCheckRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryCheckRequestTwo;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryLogInsertRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryLogSelectNoRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryLogUpdateCloseRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryUpdateStatusRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.MemberCheckRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.MemberUpdateRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.StudentListCheckRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.TroubleReportInsertRequest;
import com.example.jaewookjoo.jjw01_graduation.SecureCoding.Encryption;

import org.json.JSONObject;

import java.lang.reflect.Member;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;

//Activity 로 만들되, CreateNdefMessageCallback 과 OnNdefPushCompleteCallback 인터페이스를 추가해줍니다.
public class NfcLaboratoryCloseActivity extends MainActivity implements CreateNdefMessageCallback,
        OnNdefPushCompleteCallback{

    private static final int MESSAGE_SENT = 1; //추후 Handler 메시지에 사용
    private NfcAdapter mNfcAdapter; //NfcAdapter 를 선언

    int laboratory_No;

    Response.Listener<String> responseListener44;
    Response.Listener<String> responseListener66;
    Response.Listener<String> responseListener666;
    Response.Listener<String> responseListener99;
    Response.Listener<String> responseListener100;

    Button Close_CloseButton;
    Button Close_RentalCloseButton;

    public final String adminClose= "adminClose";


    public final String failureCode= "thief";

    String finalCode = "thief";
    boolean rentalClose = false;

    @Override
    public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        // Nfc 로 전송할 메시지 선언​

        setContentView(R.layout.activity_nfclaboratoryclose);

        Close_CloseButton = (Button) findViewById(R.id.Close_CloseButton);
        Close_RentalCloseButton = (Button) findViewById(R.id.Close_RentalCloseButton);

        Close_CloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startLaboratoryCloseResponse();
                startLaboratoryNoResponse();
            }
        });

        Close_RentalCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startLaboratoryCloseResponse();
                startLaboratoryNoResponse();
                rentalClose = true;
            }
        });


        responseListener44 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success) {    // success 만으로 가능하다는 것이므로
                        Toast.makeText(NfcLaboratoryCloseActivity.this, "문이 잠겼습니다.", Toast.LENGTH_SHORT).show();

                    }
                    else{
                        Toast.makeText(NfcLaboratoryCloseActivity.this, "에러.", Toast.LENGTH_SHORT).show();
                    }
                    // }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };


        responseListener66 = new Response.Listener<String>(){               // laboratory_log No 가져오기

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");
                    if(success) {    // success 만으로 가능하다는 것이므로

                        laboratory_No= jsonResponse.getInt("no");
                        // laboratory_No = Integer.toString(tempA);

             //           Toast.makeText(NfcLaboratoryCloseActivity.this, "로그번호 : " + laboratory_No, Toast.LENGTH_SHORT).show();
                    }
                    else{
              //          Toast.makeText(NfcLaboratoryCloseActivity.this, "아ㅓㄴ된다 : " , Toast.LENGTH_SHORT).show();

                    }
                    // }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };


        responseListener666 = new Response.Listener<String>(){               // laboratory_log No 가져오기

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");
                    if(success) {    // success 만으로 가능하다는 것이므로

                       // laboratory_No= jsonResponse.getInt("no");
                        // laboratory_No = Integer.toString(tempA);

          //              Toast.makeText(NfcLaboratoryCloseActivity.this, "로그번호 : " + laboratory_No, Toast.LENGTH_SHORT).show();
                    }
                    else{
           //             Toast.makeText(NfcLaboratoryCloseActivity.this, "아ㅓㄴ된다 : " , Toast.LENGTH_SHORT).show();

                    }
                    // }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };



        responseListener99 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    success = jsonResponse.getBoolean("success");
                    if(success){
                        Toast.makeText(NfcLaboratoryCloseActivity.this,"실습실 문닫기 가능합니다. 닫아주세요.",Toast.LENGTH_SHORT).show();
                        finalCode = adminClose;
                    }
                    else{
                        Toast.makeText(NfcLaboratoryCloseActivity.this,"실습실 문닫기 불가능합니다. ",Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };


        responseListener100 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
         //           Toast.makeText(NfcLaboratoryCloseActivity.this,"Member Update 1",Toast.LENGTH_SHORT).show();
                    success = jsonResponse.getBoolean("success");
                    if(success){
       //                 Toast.makeText(NfcLaboratoryCloseActivity.this,"Member Update 성공",Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e){
                    e.printStackTrace();
       //             Toast.makeText(NfcLaboratoryCloseActivity.this,"Member Update 2",Toast.LENGTH_SHORT).show();
                }
            }
        };





//        Toast.makeText(NfcLaboratoryEnterActivity.this, "기기와 접촉해주세요.", Toast.LENGTH_SHORT).show();


        // nfc 가 사용가능한지 체크
        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (mNfcAdapter != null) {
//            mTextView.setText("기기와 접촉해주세요."); // Tap to beam to another NFC device
            Toast.makeText(NfcLaboratoryCloseActivity.this, "NFC를 사용할 수 있는 휴대기기입니다.", Toast.LENGTH_SHORT).show();
        } else {
//            mTextView.setText("이 휴대기기는 NFC를 사용할 수 없습니다."); // This phone is not NFC enabled.
            Toast.makeText(NfcLaboratoryCloseActivity.this, "이 휴대기기는 NFC를 사용할 수 없습니다.", Toast.LENGTH_SHORT).show();
        }




        // 아래 2줄은 안드로이드빔을 성공적으로 전송했을 경우 이벤트 호출을 위해서 작성
        mNfcAdapter.setNdefPushMessageCallback(this, this);
        mNfcAdapter.setOnNdefPushCompleteCallback(this, this);

    }

    // NFC 전송 타입을 설정한다... 라고 해야 하나. 아무튼 어떤 타입의 데이터를 전송할 꺼다 라고 선언하는 부분
    public NdefRecord createMimeRecord(String mimeType, byte[] payload) {
        byte[] mimeBytes = mimeType.getBytes(Charset.forName("US-ASCII"));
        NdefRecord mimeRecord = new NdefRecord(NdefRecord.TNF_MIME_MEDIA,
                mimeBytes, new byte[0], payload);
        Log.d("createMimeRecord", "createMimeRecord");
        return mimeRecord;
    }

    // 실질적으로 Nfc 메시지(정확히는 NdefMessage라고 함) 를 생성하는 부분
    @Override
    public NdefMessage createNdefMessage(NfcEvent event) {
        //    String text = ("uniqueNo:" + uniqueNo +"\n"+"subject_uniqueNo:"+ subject_uniqueNo + "\n");
//        String text = ("uniqueNo:" + uniqueNo);
        String text = ("code:" + finalCode);

        NdefMessage msg = new NdefMessage(new NdefRecord[] { createMimeRecord(
                "Text", text.getBytes())

                // ,NdefRecord.createApplicationRecord("com.example.android.beam")
        });
        Log.d("createNdefMessage", "createNdefMessage");
        return msg;
    }

    //안드로이드 빔 보내는 작업이 성공적으로 끝날 경우 호출
// 단, 메인 쓰레드에서 동작하는게 아니기 때문에, handler를 통해서 다른 작업(Toast나 ui 변경 작업)을 해야함
    @Override
    public void onNdefPushComplete(NfcEvent arg0) {
        Log.d("onNdefPushComplete", "onNdefPushComplete");
        mHandler.obtainMessage(MESSAGE_SENT).sendToTarget();
    }
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_SENT:
//                    Toast.makeText(getApplicationContext(), "send message!!!",Toast.LENGTH_SHORT).show();
                    if(finalCode.equals(failureCode)){
                        Toast.makeText(getApplicationContext(), "실패했으므로 insert / update 불가",Toast.LENGTH_SHORT).show();
                    }

                    if(!rentalClose && finalCode.equals(adminClose)){

                        Date now = new Date();
                        String closeTime = new SimpleDateFormat("yyyy.MM.dd..HHmmss").format(now);
                        startLaboratoryLogCloseResponse(closeTime);
                        startUpdateCloseResponse();
                    }

                    //  sqlStart();
                    if( rentalClose ){
                        Date now = new Date();
                        String closeTime = new SimpleDateFormat("yyyy.MM.dd..HHmmss").format(now);
                        startLaboratoryLogCloseResponse(closeTime);
                        startUpdateCloseResponse();
               //         Toast.makeText(getApplicationContext(), "rental1",Toast.LENGTH_SHORT).show();
                        startUpdateMemberResponse();
              //          Toast.makeText(getApplicationContext(), "rental2",Toast.LENGTH_SHORT).show();
                        // update Member ( 삭제 )
                    }


                    break;
            }
        }
    };




    public void startLaboratoryNoResponse(){
        LaboratoryLogSelectNoRequest laboratoryLogSelectNoRequest = new LaboratoryLogSelectNoRequest("E513", uniqueNo , responseListener66); //시간
        RequestQueue queue6 = Volley.newRequestQueue(NfcLaboratoryCloseActivity.this);
        queue6.add(laboratoryLogSelectNoRequest);                               // where 문을 E513, 2012151039, 시간으로 설정해야 중복없이 가능.수정할것   openTime 이랑 closeTime 으로 변수를 지정해놓기.
    }

    public void startLaboratoryCloseResponse(){
        LaboratoryCheckRequest laboratoryCheckRequest = new LaboratoryCheckRequest("E513" , uniqueNo, responseListener99); //시간
        RequestQueue queue7 = Volley.newRequestQueue(NfcLaboratoryCloseActivity.this);
        queue7.add(laboratoryCheckRequest);                               // 실습실 문닫을땐 1. laboratory 테이블에 select 이용해서 opener, 실습실 명  일치한지 확인 후 일치하다면 2. update Close
    }

    public void startLaboratoryLogCloseResponse(String closeTime){
        LaboratoryLogUpdateCloseRequest laboratoryLogUpdateCloseRequest = new LaboratoryLogUpdateCloseRequest(laboratory_No, closeTime, uniqueNo, responseListener66); //시간            // 666 -> 66으로 바꾸면 됨
        RequestQueue queue8 = Volley.newRequestQueue(NfcLaboratoryCloseActivity.this);
        queue8.add(laboratoryLogUpdateCloseRequest);                // laboratory테이블 업데이트 ( status 0 )
    }

    public void startUpdateCloseResponse(){
        LaboratoryUpdateStatusRequest laboratoryUpdateStatusRequest = new LaboratoryUpdateStatusRequest("E513", "" , 0 ,laboratory_No, responseListener44);
        RequestQueue queue4 = Volley.newRequestQueue(NfcLaboratoryCloseActivity.this);
        queue4.add(laboratoryUpdateStatusRequest);
    }
    // 다르게 해야함 위에꺼랑

    public void startUpdateMemberResponse(){
        MemberUpdateRequest memberUpdateRequest = new MemberUpdateRequest("0", "E513", responseListener100);
        RequestQueue queue10 = Volley.newRequestQueue(NfcLaboratoryCloseActivity.this);
        queue10.add(memberUpdateRequest);
    }

}
