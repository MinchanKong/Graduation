package com.example.jaewookjoo.jjw01_graduation;

import android.content.DialogInterface;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcAdapter.CreateNdefMessageCallback;
import android.nfc.NfcAdapter.OnNdefPushCompleteCallback;
import android.nfc.NfcEvent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryCheckRequestTwo;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryLogInsertRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryLogSelectNoRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.LaboratoryUpdateStatusRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.MemberCheckRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.StudentListCheckRequest;

import org.json.JSONObject;

import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;

//Activity 로 만들되, CreateNdefMessageCallback 과 OnNdefPushCompleteCallback 인터페이스를 추가해줍니다.
public class NfcLaboratoryEnterActivity extends MainActivity implements CreateNdefMessageCallback,
        OnNdefPushCompleteCallback{

    private static final int MESSAGE_SENT = 1; //추후 Handler 메시지에 사용
    private NfcAdapter mNfcAdapter; //NfcAdapter 를 선언

    public int status;

    public Boolean success2 = false;


    String subject_uniqueNoTwo;
    String student_uniqueNoTwo;
    int laboratory_No;

    Response.Listener<String> responseListener11;
    Response.Listener<String> responseListener22;
    Response.Listener<String> responseListener33;

    Response.Listener<String> responseListener333;

    Response.Listener<String> responseListener44;
    Response.Listener<String> responseListener55;
    Response.Listener<String> responseListener66;
    Response.Listener<String> responseListener77;

    Button confirmButton;
    Button confirmButton2;
    Button rentalButton;
    Button finalConfirmButton2;

    // COM0001 , COM1039 수동으로 저장해놓기.
    public final String subject_uniqueNo1= "COM0001";
    public final String subject_uniqueNo2= "COM1039";
    public final String successCode= "adminOpen";
    public final String failureCode= "thief";

    String finalCode = "thief";

    boolean rental = false;
    boolean enter = false;


    @Override
    public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        // Nfc 로 전송할 메시지 선언​

        setContentView(R.layout.activity_nfclaboratoryenter);


        confirmButton = (Button) findViewById(R.id.confirmButton);
        confirmButton2 = (Button) findViewById(R.id.confirmButton2);
        rentalButton = (Button) findViewById(R.id.rentalButton);
        finalConfirmButton2 = (Button) findViewById(R.id.finalConfirmButton2);

        confirmButton2.setEnabled(false);
        finalConfirmButton2.setEnabled(false);

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startResponse1();
            }
        });

        confirmButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startResponse2();
//                finalCode = successCode;
//                enter = true;
//                Toast.makeText(NfcLaboratoryEnterActivity.this, finalCode + "기기와 접촉해주세요.", Toast.LENGTH_SHORT).show();
            }
        });

        rentalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startMemberResponse();
            }
        });

        finalConfirmButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startUpdateResponse();
            }
        });

        // 1. laboratory 에서 E513 사용중인지 확인
        responseListener11 = new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    success2 = jsonResponse.getBoolean("success");
                    if (success2) {
                        status = jsonResponse.getInt("status");
                        if(status == 0){
                            confirmButton2.setEnabled(true);
                            confirmButton.setEnabled(false);
                            confirmButton.setText("");
                            confirmButton2.setText("학생이 현재 실습실을 사용하는과목인지 확인");
                            Toast.makeText(NfcLaboratoryEnterActivity.this,"실습실이 비어있습니다." ,Toast.LENGTH_LONG).show();
                        }
                        else{ // status == 1 인경우 사용중임.
                            confirmButton.setEnabled(false);
                            Toast.makeText(NfcLaboratoryEnterActivity.this,"실습실이 사용중입니다." ,Toast.LENGTH_LONG).show();
                        }
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        // 2. student List check
        // 학생이 이 강의실을 사용하는지 확인 하기 위해서는

        responseListener22 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success){
                        subject_uniqueNoTwo = jsonResponse.getString("subject_uniqueNo");   //
                        student_uniqueNoTwo = jsonResponse.getString("student_uniqueNo");   // 필요없음
                        if( subject_uniqueNo1.equals(subject_uniqueNoTwo) || subject_uniqueNo2.equals(subject_uniqueNoTwo)){
                            Toast.makeText(NfcLaboratoryEnterActivity.this,"기기와 접촉해주세요.",Toast.LENGTH_LONG).show();
                            confirmButton.setEnabled(false);
                            finalCode = successCode;
                            enter = true;

                        }
                        else{
                            Toast.makeText(NfcLaboratoryEnterActivity.this,"실습실을 사용하지 않는 학생입니다. 불가능합니다.",Toast.LENGTH_LONG).show();
                            confirmButton.setEnabled(false);
                            confirmButton2.setEnabled(false);
                        }
                    }

                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };



        responseListener33 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success){    // success 만으로 가능하다는 것이므로
                        finalCode = successCode;
                        enter = true;
                        Toast.makeText(NfcLaboratoryEnterActivity.this,  "기기와 접촉해주세요.", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(NfcLaboratoryEnterActivity.this,  "불가능합니다.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        responseListener333 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success){    // success 만으로 가능하다는 것이므로
                        finalCode = successCode;
                        rental = true;
                        finalConfirmButton2.setEnabled(true);
                        rentalButton.setEnabled(false);
                        rentalButton.setText("");
                        finalConfirmButton2.setText("실습실 대여");
                        Toast.makeText(NfcLaboratoryEnterActivity.this, "아래 실습실 대여 버튼을 눌러주세요", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(NfcLaboratoryEnterActivity.this, "대여 목록을 확인하세요. 불가능합니다.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        responseListener44 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success) {    // success 만으로 가능하다는 것이므로
                        Toast.makeText(NfcLaboratoryEnterActivity.this, "기기와 접촉해주세요.", Toast.LENGTH_SHORT).show();
                    }
                    // }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        responseListener55 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success) {    // success 만으로 가능하다는 것이므로
                        Toast.makeText(NfcLaboratoryEnterActivity.this, "insert 성공", Toast.LENGTH_SHORT).show();

                    }
                    // }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        responseListener66 = new Response.Listener<String>(){               // laboratory_log No 가져오기

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");
                    if(success) {    // success 만으로 가능하다는 것이므로
                       laboratory_No= jsonResponse.getInt("no");
            //            Toast.makeText(NfcLaboratoryEnterActivity.this, "로그번호 : " + laboratory_No, Toast.LENGTH_SHORT).show();
                    }
                    else{
            //            Toast.makeText(NfcLaboratoryEnterActivity.this, "아ㅓㄴ된다 : " , Toast.LENGTH_SHORT).show();
                    }
                    // }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        responseListener77 = new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);

                    boolean success = jsonResponse.getBoolean("success");
                    if(success) {    // success 만으로 가능하다는 것이므로
                        Toast.makeText(NfcLaboratoryEnterActivity.this, "update Close 성공", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        };

        // nfc 가 사용가능한지 체크
        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (mNfcAdapter != null) {
//            mTextView.setText("기기와 접촉해주세요."); // Tap to beam to another NFC device
            Toast.makeText(NfcLaboratoryEnterActivity.this, "NFC를 사용할 수 있는 휴대기기입니다.", Toast.LENGTH_SHORT).show();
        } else {
//            mTextView.setText("이 휴대기기는 NFC를 사용할 수 없습니다."); // This phone is not NFC enabled.
            Toast.makeText(NfcLaboratoryEnterActivity.this, "이 휴대기기는 NFC를 사용할 수 없습니다.", Toast.LENGTH_SHORT).show();
        }

        // 아래 2줄은 안드로이드빔을 성공적으로 전송했을 경우 이벤트 호출을 위해서 작성
        mNfcAdapter.setNdefPushMessageCallback(this, this);
        mNfcAdapter.setOnNdefPushCompleteCallback(this, this);
    }

    // NFC 전송 타입을 설정한다... 라고 해야 하나. 아무튼 어떤 타입의 데이터를 전송할 꺼다 라고 선언하는 부분
    public NdefRecord createMimeRecord(String mimeType, byte[] payload) {
        byte[] mimeBytes = mimeType.getBytes(Charset.forName("US-ASCII"));
        NdefRecord mimeRecord = new NdefRecord(NdefRecord.TNF_MIME_MEDIA,
                mimeBytes, new byte[0], payload);
        Log.d("createMimeRecord", "createMimeRecord");
        return mimeRecord;
    }

    // 실질적으로 Nfc 메시지(정확히는 NdefMessage라고 함) 를 생성하는 부분
    @Override
    public NdefMessage createNdefMessage(NfcEvent event) {
    //    String text = ("uniqueNo:" + uniqueNo +"\n"+"subject_uniqueNo:"+ subject_uniqueNo + "\n");
//        String text = ("uniqueNo:" + uniqueNo);
        String text = ("code:" + finalCode);

        NdefMessage msg = new NdefMessage(new NdefRecord[] { createMimeRecord(
                "Text", text.getBytes())

                // ,NdefRecord.createApplicationRecord("com.example.android.beam")
        });
        Log.d("createNdefMessage", "createNdefMessage");
        return msg;
    }

    //안드로이드 빔 보내는 작업이 성공적으로 끝날 경우 호출
// 단, 메인 쓰레드에서 동작하는게 아니기 때문에, handler를 통해서 다른 작업(Toast나 ui 변경 작업)을 해야함
    @Override
    public void onNdefPushComplete(NfcEvent arg0) {
        Log.d("onNdefPushComplete", "onNdefPushComplete");
        mHandler.obtainMessage(MESSAGE_SENT).sendToTarget();
    }
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MESSAGE_SENT:
//                    Toast.makeText(getApplicationContext(), "send message!!!",Toast.LENGTH_SHORT).show();
                    if(finalCode.equals(failureCode)){
                        Toast.makeText(getApplicationContext(), "불가능합니다.",Toast.LENGTH_SHORT).show();
                    }
                    else if(enter && finalCode.equals(successCode)){
                        startInsertResponse();
                        startLaboratoryNoResponse();

                        Toast.makeText(getApplicationContext(), "성공했으면 insert / update 설정하면 됨",Toast.LENGTH_SHORT).show();
                        AlertDialog.Builder mBuilder = new AlertDialog.Builder(NfcLaboratoryEnterActivity.this);
                        View mView = getLayoutInflater().inflate(R.layout.dialog_checkenter, null);

                        mBuilder.setView(mView);
                        mBuilder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                startUpdateResponse();
                            }
                        });
                        mBuilder.show();
                    }

                    if( rental && finalCode.equals(successCode)){
         //               Toast.makeText(getApplicationContext(), "TTTTTTTTTTTTT",Toast.LENGTH_SHORT).show();
                        startInsertResponse();
                        startLaboratoryNoResponse();
                    }
                    break;
            }
        }
    };

    public void startResponse1(){
        LaboratoryCheckRequestTwo laboratoryCheckRequestTwo = new LaboratoryCheckRequestTwo("E513", responseListener11);
        RequestQueue queue2 = Volley.newRequestQueue(NfcLaboratoryEnterActivity.this);
        queue2.add(laboratoryCheckRequestTwo);
    }

    public void startResponse2(){
        StudentListCheckRequest studentListCheckRequest = new StudentListCheckRequest(uniqueNo, responseListener22);
        RequestQueue queue2 = Volley.newRequestQueue(NfcLaboratoryEnterActivity.this);
        queue2.add(studentListCheckRequest);
    }

    public void startMemberResponse(){
        MemberCheckRequest memberCheckRequest = new MemberCheckRequest(uniqueNo,"E513", responseListener333);
        RequestQueue queue3 = Volley.newRequestQueue(NfcLaboratoryEnterActivity.this);
        queue3.add(memberCheckRequest);
    }


    // 대여 -> 1. Member 테이블을 통해 학번과 실습실 명  확인 후 가능하다면 true
    //         2. Laboratory 테이블에서 Update 및 insert

    public void startUpdateResponse(){
        LaboratoryUpdateStatusRequest laboratoryUpdateStatusRequest = new LaboratoryUpdateStatusRequest("E513", uniqueNo , 1 ,laboratory_No, responseListener44);
        RequestQueue queue4 = Volley.newRequestQueue(NfcLaboratoryEnterActivity.this);
        queue4.add(laboratoryUpdateStatusRequest);
    }

   // String laboratory_roomName,String openTime,String opener,
   public void startInsertResponse(){
       Date now = new Date();
       String openTime = new SimpleDateFormat("yyyy.MM.dd..HHmmss").format(now);

       LaboratoryLogInsertRequest laboratoryLogInsertRequest = new LaboratoryLogInsertRequest("E513", openTime , uniqueNo , responseListener55);
       RequestQueue queue5 = Volley.newRequestQueue(NfcLaboratoryEnterActivity.this);
       queue5.add(laboratoryLogInsertRequest);
   }

    public void startLaboratoryNoResponse(){
        LaboratoryLogSelectNoRequest laboratoryLogSelectNoRequest = new LaboratoryLogSelectNoRequest("E513", uniqueNo , responseListener66); //시간
        RequestQueue queue6 = Volley.newRequestQueue(NfcLaboratoryEnterActivity.this);
        queue6.add(laboratoryLogSelectNoRequest);                               // where 문을 E513, 2012151039, 시간으로 설정해야 중복없이 가능.수정할것   openTime 이랑 closeTime 으로 변수를 지정해놓기.
    }

}
