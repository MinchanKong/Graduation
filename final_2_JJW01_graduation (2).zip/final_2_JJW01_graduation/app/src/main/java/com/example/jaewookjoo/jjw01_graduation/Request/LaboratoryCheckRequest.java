package com.example.jaewookjoo.jjw01_graduation.Request;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class LaboratoryCheckRequest extends StringRequest {

    final static private String URL = "http://jjer77.dothome.co.kr/selectLaboratory.php";
    private Map<String,String> parameters;

    public LaboratoryCheckRequest(String roomName,String holder, Response.Listener<String> listener){
        super(Method.POST, URL, listener, null);

        parameters = new HashMap<>();
        parameters.put("roomName",roomName);
        parameters.put("holder",holder);
    }

    public Map<String,String> getParams(){
        return parameters;
    }
}
