package com.example.jaewookjoo.jjw01_graduation.Request;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class LaboratoryLogSelectNoRequest extends StringRequest {

    final static private String URL = "http://jjer77.dothome.co.kr/selectLaboratoryLogNo.php";
    private Map<String,String> parameters;

    public LaboratoryLogSelectNoRequest(String laboratory_roomName, String opener, Response.Listener<String> listener){
        super(Method.POST, URL, listener, null);

        parameters = new HashMap<>();
        parameters.put("laboratory_roomName",laboratory_roomName);
        parameters.put("opener",opener);
    }

    public Map<String,String> getParams(){
        return parameters;
    }
}
