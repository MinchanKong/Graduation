package com.example.jaewookjoo.jjw01_graduation.Request;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;


public class LaboratoryLogUpdateOpenerRequest extends StringRequest {

    final static private String URL = "http://jjer77.dothome.co.kr/updateLaboratoryLogOpener.php";
    private Map<String,String> parameters;

    public LaboratoryLogUpdateOpenerRequest(String opener, int no, Response.Listener<String> listener){
        super(Method.POST, URL, listener, null);

        parameters = new HashMap<>();
        parameters.put("opener",opener);
        parameters.put("no",no + "");
    }

    public Map<String,String> getParams(){
        return parameters;
    }
}
