package com.example.jaewookjoo.jjw01_graduation.Request;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;


public class LaboratoryUpdateRequest extends StringRequest {

    final static private String URL = "http://jjer77.dothome.co.kr/updateLaboratoryAuthority.php";
    private Map<String,String> parameters;

    public LaboratoryUpdateRequest(String receiveAuthorityUniqueNo, String roomName,String holder, Response.Listener<String> listener){
        super(Method.POST, URL, listener, null);

        parameters = new HashMap<>();
        parameters.put("receiveAuthorityUniqueNo",receiveAuthorityUniqueNo);
        parameters.put("roomName",roomName);
        parameters.put("holder",holder);

    }

    public Map<String,String> getParams(){
        return parameters;
    }
}
