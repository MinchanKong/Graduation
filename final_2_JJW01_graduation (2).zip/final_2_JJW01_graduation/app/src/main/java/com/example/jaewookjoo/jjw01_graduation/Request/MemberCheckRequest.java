package com.example.jaewookjoo.jjw01_graduation.Request;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class MemberCheckRequest extends StringRequest {

    final static private String URL = "http://jjer77.dothome.co.kr/selectMember.php";
    private Map<String,String> parameters;

    public MemberCheckRequest(String student_uniqueNo, String laboratory_roomName, Response.Listener<String> listener){
        super(Method.POST, URL, listener, null);

        parameters = new HashMap<>();
        parameters.put("student_uniqueNo",student_uniqueNo);
        parameters.put("laboratory_roomName",laboratory_roomName);
    }

    public Map<String,String> getParams(){
        return parameters;
    }
}
