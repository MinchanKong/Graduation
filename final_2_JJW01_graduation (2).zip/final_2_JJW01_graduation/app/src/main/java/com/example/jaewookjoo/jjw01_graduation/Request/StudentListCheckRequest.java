package com.example.jaewookjoo.jjw01_graduation.Request;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class StudentListCheckRequest extends StringRequest {

    final static private String URL = "http://jjer77.dothome.co.kr/selectStudent_list.php";
    private Map<String,String> parameters;

    public StudentListCheckRequest(String student_uniqueNo, Response.Listener<String> listener){
        super(Method.POST, URL, listener, null);

        parameters = new HashMap<>();
        parameters.put("student_uniqueNo",student_uniqueNo);
    }

    public Map<String,String> getParams(){
        return parameters;
    }
}
