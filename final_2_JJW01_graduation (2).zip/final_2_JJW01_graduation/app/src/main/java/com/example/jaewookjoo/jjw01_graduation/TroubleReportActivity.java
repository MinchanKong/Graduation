package com.example.jaewookjoo.jjw01_graduation;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.example.jaewookjoo.jjw01_graduation.Request.AuthorityLogInsertRequest;
import com.example.jaewookjoo.jjw01_graduation.Request.TroubleReportInsertRequest;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TroubleReportActivity extends LoginActivity {
    Button troubleReportSubmitButton;
    EditText editTextItem;
    EditText editTextContent;

    String dateTime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_troublereport);

        troubleReportSubmitButton = (Button)findViewById(R.id.troubleReportSubmitButton);
        editTextItem = (EditText)findViewById(R.id.editTextItem);
        editTextContent = (EditText)findViewById(R.id.editTextContent);

        Spinner spinner = (Spinner)findViewById(R.id.spinnerLaboratoryRoomName);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,R.array.laboratoryRoom_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new MyOnItemSelectedListener());


        troubleReportSubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Date now = new Date();
                dateTime = new SimpleDateFormat("yyyy.MM.dd..HHmmss").format(now);

                Response.Listener<String> responseListener = new Response.Listener<String>(){

                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);

                            boolean success = jsonResponse.getBoolean("success");
                            if(success){
                                Toast.makeText(TroubleReportActivity.this,"전송되었습니다." ,Toast.LENGTH_LONG).show();
                            }
                            else{
                                Toast.makeText(TroubleReportActivity.this,"실패" ,Toast.LENGTH_LONG).show();
                            }

                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                };

                TroubleReportInsertRequest troubleReportInsertRequest = new TroubleReportInsertRequest( "E513",
                        dateTime, editTextItem.getText().toString(), editTextContent.getText().toString(),uniqueNo, responseListener);
                RequestQueue queue = Volley.newRequestQueue(TroubleReportActivity.this);
                queue.add(troubleReportInsertRequest);

            }
        });
    }

    public class MyOnItemSelectedListener implements AdapterView.OnItemSelectedListener{
        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            Toast.makeText(TroubleReportActivity.this,"선택한 강의실은 "+ adapterView.getItemAtPosition(i) + " 입니다.",Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {
            // do nothing
        }
    }
}